import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";

interface Patient {
  id: number;
  firstName: string;
  lastName: string;
  age: number;
  gender: string;
}

const KPI_CARDS = [
  { label: "Total Patients", value: "1,284", icon: "👥", color: "bg-blue-50 text-blue-700" },
  { label: "Today's Appointments", value: "38", icon: "📅", color: "bg-green-50 text-green-700" },
  { label: "Available Doctors", value: "12", icon: "🩺", color: "bg-purple-50 text-purple-700" },
  { label: "Available Beds", value: "47", icon: "🛏️", color: "bg-orange-50 text-orange-700" },
];

const STATUSES = ["Admitted", "Outpatient"];

export default function DashboardPage() {
  const { user } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchPatients = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("https://dummyjson.com/users?limit=5");
      const data = await res.json();
      setPatients(data.users);
    } catch {
      setError("Failed to load recent patients.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchPatients(); }, []);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {user?.firstName}! 👋
          </h1>
          <p className="text-gray-500 mt-1">Here's what's happening with your clinic today</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {KPI_CARDS.map((card) => (
          <div key={card.label} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-gray-100">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 ${card.color} rounded-xl flex items-center justify-center text-2xl shadow-md`}>
                {card.icon}
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">{card.value}</div>
            <div className="text-sm font-medium text-gray-500">{card.label}</div>
          </div>
        ))}
      </div>

      {/* Recent Patients */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Recent Patients</h2>
          <span className="text-xs bg-blue-50 text-blue-700 px-3 py-1 rounded-full font-semibold">Last 5</span>
        </div>
        {loading && <div className="flex items-center justify-center py-12"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div></div>}
        {error && (
          <div className="text-red-600 text-sm flex items-center gap-3 bg-red-50 p-4 rounded-xl border border-red-200">
            <span>⚠️</span>
            <span>{error}</span>
            <button onClick={fetchPatients} className="ml-auto text-red-700 underline font-semibold">Retry</button>
          </div>
        )}
        {!loading && !error && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b-2 border-gray-100">
                  <th className="pb-4 font-semibold">Name</th>
                  <th className="pb-4 font-semibold">Age</th>
                  <th className="pb-4 font-semibold">Gender</th>
                  <th className="pb-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {patients.map((p, i) => (
                  <tr key={p.id} className="hover:bg-gray-50 transition-colors">
                    <td className="py-4 font-semibold text-gray-900">{p.firstName} {p.lastName}</td>
                    <td className="py-4 text-gray-600">{p.age}</td>
                    <td className="py-4 text-gray-600 capitalize">{p.gender}</td>
                    <td className="py-4">
                      <span className={`px-3 py-1.5 rounded-full text-xs font-semibold
                        ${STATUSES[i % 2] === "Admitted" ? "bg-red-50 text-red-700 border border-red-200" : "bg-green-50 text-green-700 border border-green-200"}`}>
                        {STATUSES[i % 2]}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
