export type Doctor = {
  id: number;
  name: string;
  specialization: string;
  department: string;
  status: "On Duty" | "Off Duty";
  experience: string;
  email: string;
  phone: string;
};

export const mockDoctors: Doctor[] = [
  { id: 1, name: "Dr. Emily Smith", specialization: "Cardiologist", department: "Cardiology", status: "On Duty", experience: "12 years", email: "e.smith@clinic.com", phone: "+1-555-0101" },
  { id: 2, name: "Dr. James Patel", specialization: "Pediatrician", department: "Pediatrics", status: "On Duty", experience: "8 years", email: "j.patel@clinic.com", phone: "+1-555-0102" },
  { id: 3, name: "Dr. Sarah Lee", specialization: "General Practitioner", department: "General", status: "Off Duty", experience: "5 years", email: "s.lee@clinic.com", phone: "+1-555-0103" },
  { id: 4, name: "Dr. Michael Brown", specialization: "Neurologist", department: "Neurology", status: "On Duty", experience: "15 years", email: "m.brown@clinic.com", phone: "+1-555-0104" },
  { id: 5, name: "Dr. Lisa Chen", specialization: "Cardiologist", department: "Cardiology", status: "Off Duty", experience: "10 years", email: "l.chen@clinic.com", phone: "+1-555-0105" },
  { id: 6, name: "Dr. Robert Kim", specialization: "Pediatrician", department: "Pediatrics", status: "On Duty", experience: "7 years", email: "r.kim@clinic.com", phone: "+1-555-0106" },
  { id: 7, name: "Dr. Anna White", specialization: "General Practitioner", department: "General", status: "On Duty", experience: "3 years", email: "a.white@clinic.com", phone: "+1-555-0107" },
  { id: 8, name: "Dr. David Garcia", specialization: "Neurologist", department: "Neurology", status: "Off Duty", experience: "20 years", email: "d.garcia@clinic.com", phone: "+1-555-0108" },
];

export const departments = ["All", "Cardiology", "Pediatrics", "General", "Neurology"];
