# Healthcare Admin Portal

A React + TypeScript web application for managing clinic operations including patients, appointments, and doctor profiles.

## Tech Stack

- **Framework:** React 18 + TypeScript
- **Routing:** React Router v6
- **Styling:** Tailwind CSS
- **Build Tool:** Vite
- **API:** DummyJSON (for users/auth) + Mock data (for appointments/doctors)

## Features

### Day 1
- ✅ Login page with authentication
- ✅ Protected routes with auth guard
- ✅ Dashboard with KPI cards and recent patients table
- ✅ Patients listing with search and detail modal
- ✅ Responsive layout (navbar + sidebar)

### Day 2
- ✅ Appointments page with status filter and add/cancel functionality
- ✅ Doctors page with department filter and card grid
- ✅ Loading states and error handling
- ✅ Logout functionality

## Prerequisites

- **Node.js** (v16 or higher)
- **npm** (comes with Node.js)

## Installation & Setup

1. **Clone or download the project**
   ```bash
   cd healthcare-admin
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   ```
   http://localhost:5173
   ```

## Login Credentials

Use these test credentials from DummyJSON:

- **Username:** `emilys`
- **Password:** `emilyspass`

Other valid users: `michaelw` / `michaelwpass`, `sophiab` / `sophiabpass`

## Project Structure

```
src/
├── components/
│   ├── Layout.tsx              # Main layout with navbar + sidebar
│   └── ProtectedRoute.tsx      # Auth guard wrapper
├── context/
│   └── AuthContext.tsx         # Global auth state management
├── data/
│   ├── appointments.ts         # Mock appointment data
│   └── doctors.ts              # Mock doctor data
├── pages/
│   ├── LoginPage.tsx           # Login form
│   ├── DashboardPage.tsx       # Dashboard with KPIs
│   ├── PatientsPage.tsx        # Patient listing + search
│   ├── AppointmentsPage.tsx    # Appointments management
│   └── DoctorsPage.tsx         # Doctor profiles grid
├── App.tsx                     # Router setup
├── main.tsx                    # App entry point
└── index.css                   # Tailwind imports
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## API Endpoints Used

- `POST https://dummyjson.com/auth/login` - User authentication
- `GET https://dummyjson.com/users?limit=20` - Fetch patients (repurposed users)

## Features Breakdown

### Login Page
- Email/password validation
- API integration with DummyJSON
- Error handling for invalid credentials
- Token storage in localStorage

### Dashboard
- 4 KPI cards (hardcoded values)
- Recent patients table (first 5 from API)
- Welcome message with logged-in user name

### Patients Page
- Fetch 20 users from DummyJSON
- Real-time search filter by name
- Patient detail modal with full info
- Loading spinner and error states

### Appointments Page
- Mock data (no API)
- Status filter (All/Scheduled/Completed/Cancelled)
- Add appointment modal with form validation
- Cancel appointment per row

### Doctors Page
- Mock data (no API)
- Card grid layout (responsive)
- Department filter buttons
- Doctor detail modal
- Avatar images from UI Avatars API

## Troubleshooting

### Blank page after npm run dev
- Hard refresh: `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac)
- Clear Vite cache: `Remove-Item -Recurse -Force node_modules/.vite` then restart

### Module export errors
- Stop dev server and restart
- Clear browser cache

### npm command not found
- Install Node.js from https://nodejs.org
- Restart terminal after installation

## Browser Support

- Chrome (recommended)
- Firefox
- Edge
- Safari

## Notes

- This is a learning project with simplified authentication (no refresh tokens)
- Mock data is used for appointments and doctors as per assignment requirements
- Responsive design works on mobile, tablet, and desktop
