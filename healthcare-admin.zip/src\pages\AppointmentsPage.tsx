import { useState } from "react";
import { mockAppointments } from "../data/appointments";

type Appointment = {
  id: number;
  patientName: string;
  doctor: string;
  date: string;
  time: string;
  type: "Checkup" | "Emergency" | "Follow-up";
  status: "Scheduled" | "Completed" | "Cancelled";
};

type Status = "All" | "Scheduled" | "Completed" | "Cancelled";
type AppType = "Checkup" | "Emergency" | "Follow-up";

const STATUS_COLORS: Record<string, string> = {
  Scheduled: "bg-blue-50 text-blue-700 border-blue-200",
  Completed: "bg-green-50 text-green-700 border-green-200",
  Cancelled: "bg-red-50 text-red-700 border-red-200",
};

const TYPE_COLORS: Record<string, string> = {
  Checkup: "bg-gray-50 text-gray-700 border-gray-200",
  Emergency: "bg-red-50 text-red-700 border-red-200",
  "Follow-up": "bg-purple-50 text-purple-700 border-purple-200",
};

const emptyForm = { patientName: "", doctor: "", date: "", time: "", type: "Checkup" as AppType };

export default function AppointmentsPage() {
  const [appointments, setAppointments] = useState<Appointment[]>(mockAppointments);
  const [statusFilter, setStatusFilter] = useState<Status>("All");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState("");

  const filtered = appointments.filter(
    (a) => statusFilter === "All" || a.status === statusFilter
  );

  const handleCancel = (id: number) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: "Cancelled" } : a))
    );
  };

  const handleAdd = () => {
    if (!form.patientName || !form.doctor || !form.date || !form.time) {
      setFormError("All fields are required.");
      return;
    }
    const newAppt: Appointment = {
      id: Date.now(),
      ...form,
      status: "Scheduled",
    };
    setAppointments((prev) => [newAppt, ...prev]);
    setShowModal(false);
    setForm(emptyForm);
    setFormError("");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Appointments</h1>
          <p className="text-gray-500 mt-1">Schedule and manage patient appointments</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl text-sm font-semibold hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all"
        >
          + Add Appointment
        </button>
      </div>

      {/* Status Filter */}
      <div className="flex gap-3 flex-wrap">
        {(["All", "Scheduled", "Completed", "Cancelled"] as Status[]).map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-5 py-2.5 rounded-xl text-sm font-semibold border-2 transition-all
              ${statusFilter === s 
                ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-transparent shadow-lg" 
                : "bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
              <tr className="text-left text-gray-600">
                <th className="px-6 py-4 font-semibold">Patient</th>
                <th className="px-6 py-4 font-semibold">Doctor</th>
                <th className="px-6 py-4 font-semibold">Date</th>
                <th className="px-6 py-4 font-semibold">Time</th>
                <th className="px-6 py-4 font-semibold">Type</th>
                <th className="px-6 py-4 font-semibold">Status</th>
                <th className="px-6 py-4 font-semibold"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-400">
                    <div className="text-4xl mb-2">📅</div>
                    <p>No appointments found</p>
                  </td>
                </tr>
              ) : (
                filtered.map((a) => (
                  <tr key={a.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 font-semibold text-gray-900">{a.patientName}</td>
                    <td className="px-6 py-4 text-gray-600">{a.doctor}</td>
                    <td className="px-6 py-4 text-gray-600">{a.date}</td>
                    <td className="px-6 py-4 text-gray-600">{a.time}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1.5 rounded-full text-xs font-semibold border ${TYPE_COLORS[a.type]}`}>
                        {a.type}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1.5 rounded-full text-xs font-semibold border ${STATUS_COLORS[a.status]}`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {a.status !== "Cancelled" && (
                        <button
                          onClick={() => handleCancel(a.id)}
                          className="text-red-600 hover:text-red-700 text-sm font-semibold hover:underline"
                        >
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Appointment Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-8">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">New Appointment</h2>
                <p className="text-sm text-gray-500 mt-1">Schedule a new patient appointment</p>
              </div>
              <button onClick={() => { setShowModal(false); setFormError(""); }} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">✕</button>
            </div>
            <div className="space-y-4">
              {[
                { label: "Patient Name", key: "patientName", type: "text" },
                { label: "Doctor", key: "doctor", type: "text" },
                { label: "Date", key: "date", type: "date" },
                { label: "Time", key: "time", type: "time" },
              ].map(({ label, key, type }) => (
                <div key={key}>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">{label}</label>
                  <input
                    type={type}
                    value={form[key as keyof typeof form]}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                    className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all"
                  />
                </div>
              ))}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Type</label>
                <select
                  value={form.type}
                  onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as AppType }))}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all"
                >
                  <option>Checkup</option>
                  <option>Emergency</option>
                  <option>Follow-up</option>
                </select>
              </div>
              {formError && <p className="text-red-600 text-sm bg-red-50 p-3 rounded-xl border border-red-200">{formError}</p>}
            </div>
            <div className="flex gap-3 mt-8">
              <button
                onClick={() => { setShowModal(false); setFormError(""); setForm(emptyForm); }}
                className="flex-1 border-2 border-gray-200 text-gray-700 py-3 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleAdd}
                className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-xl text-sm font-semibold hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all"
              >
                Add Appointment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
