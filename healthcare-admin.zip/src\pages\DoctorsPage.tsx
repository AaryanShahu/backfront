import { useState } from "react";
import { mockDoctors, departments } from "../data/doctors";

type Doctor = {
  id: number;
  name: string;
  specialization: string;
  department: string;
  status: "On Duty" | "Off Duty";
  experience: string;
  email: string;
  phone: string;
};

export default function DoctorsPage() {
  const [deptFilter, setDeptFilter] = useState("All");
  const [selected, setSelected] = useState<Doctor | null>(null);

  const filtered = mockDoctors.filter(
    (d) => deptFilter === "All" || d.department === deptFilter
  );

  const getAvatarUrl = (name: string) =>
    `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&size=80`;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Medical Staff</h1>
        <p className="text-gray-500 mt-1">Browse and manage doctor profiles</p>
      </div>

      {/* Department Filter */}
      <div className="flex gap-3 flex-wrap">
        {departments.map((dept) => (
          <button
            key={dept}
            onClick={() => setDeptFilter(dept)}
            className={`px-5 py-2.5 rounded-xl text-sm font-semibold border-2 transition-all
              ${deptFilter === dept 
                ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-transparent shadow-lg" 
                : "bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`}
          >
            {dept}
          </button>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16">
          <div className="text-5xl mb-3">🩺</div>
          <p className="text-gray-400">No doctors found for this department</p>
        </div>
      )}

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filtered.map((doctor) => (
          <div
            key={doctor.id}
            onClick={() => setSelected(doctor)}
            className="bg-white rounded-2xl shadow-lg p-6 cursor-pointer hover:shadow-xl transition-all border border-gray-100 hover:scale-105 transform"
          >
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-4">
                <img
                  src={getAvatarUrl(doctor.name)}
                  alt={doctor.name}
                  className="w-20 h-20 rounded-2xl shadow-md"
                />
                <div className={`absolute -bottom-2 -right-2 w-6 h-6 rounded-full border-2 border-white shadow-md
                  ${doctor.status === "On Duty" ? "bg-green-500" : "bg-gray-400"}`}
                />
              </div>
              <h3 className="font-bold text-gray-900 text-base">{doctor.name}</h3>
              <p className="text-gray-500 text-sm mt-1">{doctor.specialization}</p>
              <p className="text-gray-400 text-xs mt-0.5">{doctor.department}</p>
              <span className={`mt-4 px-4 py-2 rounded-xl text-xs font-semibold border-2
                ${doctor.status === "On Duty" 
                  ? "bg-green-50 text-green-700 border-green-200" 
                  : "bg-gray-50 text-gray-500 border-gray-200"}`}>
                {doctor.status}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Doctor Detail Modal */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-8">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Doctor Profile</h2>
                <p className="text-sm text-gray-500 mt-1">Complete professional information</p>
              </div>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">✕</button>
            </div>
            <div className="flex flex-col items-center mb-6">
              <img
                src={`https://ui-avatars.com/api/?name=${encodeURIComponent(selected.name)}&background=random&size=120`}
                alt={selected.name}
                className="w-24 h-24 rounded-2xl shadow-lg mb-4"
              />
              <h3 className="font-bold text-xl text-gray-900">{selected.name}</h3>
              <p className="text-gray-500 text-sm mt-1">{selected.specialization}</p>
            </div>
            <div className="space-y-3 text-sm">
              {[
                ["Department", selected.department],
                ["Status", selected.status],
                ["Experience", selected.experience],
                ["Email", selected.email],
                ["Phone", selected.phone],
              ].map(([label, value]) => (
                <div key={label} className="flex gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-gray-500 w-28 shrink-0 font-semibold">{label}:</span>
                  <span className="text-gray-900 font-medium">{value}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => setSelected(null)}
              className="mt-8 w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-xl text-sm font-semibold hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
