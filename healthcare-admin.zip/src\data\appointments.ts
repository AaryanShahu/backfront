export type Appointment = {
  id: number;
  patientName: string;
  doctor: string;
  date: string;
  time: string;
  type: "Checkup" | "Emergency" | "Follow-up";
  status: "Scheduled" | "Completed" | "Cancelled";
};

export const mockAppointments: Appointment[] = [
  { id: 1, patientName: "Alice Johnson", doctor: "Dr. Smith", date: "2026-04-12", time: "09:00", type: "Checkup", status: "Scheduled" },
  { id: 2, patientName: "Bob Williams", doctor: "Dr. Patel", date: "2026-04-12", time: "10:30", type: "Follow-up", status: "Completed" },
  { id: 3, patientName: "Carol Davis", doctor: "Dr. Lee", date: "2026-04-13", time: "11:00", type: "Emergency", status: "Scheduled" },
  { id: 4, patientName: "David Brown", doctor: "Dr. Smith", date: "2026-04-13", time: "14:00", type: "Checkup", status: "Cancelled" },
  { id: 5, patientName: "Eva Martinez", doctor: "Dr. Patel", date: "2026-04-14", time: "09:30", type: "Follow-up", status: "Scheduled" },
  { id: 6, patientName: "Frank Wilson", doctor: "Dr. Lee", date: "2026-04-14", time: "15:00", type: "Checkup", status: "Completed" },
  { id: 7, patientName: "Grace Taylor", doctor: "Dr. Smith", date: "2026-04-15", time: "08:00", type: "Emergency", status: "Scheduled" },
];
