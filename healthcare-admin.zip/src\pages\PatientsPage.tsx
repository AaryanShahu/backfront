import { useEffect, useState } from "react";

interface Patient {
  id: number;
  firstName: string;
  lastName: string;
  age: number;
  gender: string;
  email: string;
  phone: string;
  address: { address: string; city: string; state: string };
}

export default function PatientsPage() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Patient | null>(null);

  const fetchPatients = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("https://dummyjson.com/users?limit=20");
      const data = await res.json();
      setPatients(data.users);
    } catch {
      setError("Failed to load patients.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchPatients(); }, []);

  const filtered = patients.filter((p) =>
    `${p.firstName} ${p.lastName}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Patients Directory</h1>
        <p className="text-gray-500 mt-1">Manage and view all patient records</p>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">🔍</span>
          <input
            type="text"
            placeholder="Search by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border-2 border-gray-200 rounded-xl pl-11 pr-4 py-3 text-sm w-full focus:outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all"
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">
        {loading && <div className="flex items-center justify-center py-16"><div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div></div>}
        {error && (
          <div className="p-6 text-red-600 text-sm flex gap-3 bg-red-50 border-b border-red-200">
            <span>⚠️</span>
            <span>{error}</span>
            <button onClick={fetchPatients} className="ml-auto underline font-semibold">Retry</button>
          </div>
        )}
        {!loading && !error && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gradient-to-r from-gray-50 to-gray-100">
                <tr className="text-left text-gray-600">
                  <th className="px-6 py-4 font-semibold">Name</th>
                  <th className="px-6 py-4 font-semibold">Email</th>
                  <th className="px-6 py-4 font-semibold">Age</th>
                  <th className="px-6 py-4 font-semibold">Phone</th>
                  <th className="px-6 py-4 font-semibold">City</th>
                  <th className="px-6 py-4 font-semibold"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-400">
                      <div className="text-4xl mb-2">🔍</div>
                      <p>No patients found</p>
                    </td>
                  </tr>
                ) : (
                  filtered.map((p) => (
                    <tr key={p.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 font-semibold text-gray-900">{p.firstName} {p.lastName}</td>
                      <td className="px-6 py-4 text-gray-600">{p.email}</td>
                      <td className="px-6 py-4 text-gray-600">{p.age}</td>
                      <td className="px-6 py-4 text-gray-600">{p.phone}</td>
                      <td className="px-6 py-4 text-gray-600">{p.address?.city}</td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => setSelected(p)}
                          className="text-blue-600 hover:text-blue-700 text-sm font-semibold hover:underline"
                        >
                          View Details →
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Patient Detail Modal */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-8 animate-in">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Patient Details</h2>
                <p className="text-sm text-gray-500 mt-1">Complete patient information</p>
              </div>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">✕</button>
            </div>
            <div className="space-y-4 text-sm">
              {[
                ["Name", `${selected.firstName} ${selected.lastName}`],
                ["Email", selected.email],
                ["Phone", selected.phone],
                ["Age", selected.age],
                ["Gender", selected.gender],
                ["Address", `${selected.address?.address}, ${selected.address?.city}, ${selected.address?.state}`],
              ].map(([label, value]) => (
                <div key={String(label)} className="flex gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-gray-500 w-24 shrink-0 font-semibold">{label}:</span>
                  <span className="text-gray-900 font-medium capitalize">{String(value)}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => setSelected(null)}
              className="mt-8 w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-xl text-sm font-semibold hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
