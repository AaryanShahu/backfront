import java.util.*;
import java.util.stream.Collectors;

/**
 * =====================================================================
 * GYM MEMBERSHIP — Karat Coding Problem (Scenario-Based)
 * =====================================================================
 *
 * We are building a program to manage a gym's membership. The gym has
 * multiple members, each with a unique ID, name, and membership status.
 *
 * Classes:
 *   MembershipStatus — enum: BRONZE (default), SILVER, GOLD (paid)
 *   Workout          — workout session (id, startTime, endTime in minutes)
 *   Member           — gym member (memberId, name, membershipStatus)
 *   MembershipStatistics — stats result object
 *   Membership       — manages members and workouts
 *
 * TASK 1: Read the code. The test for Membership is not passing
 *         due to a bug. Find and fix the bug.
 *
 * TASK 2: Implement addWorkout() and getAverageWorkoutDurations():
 *   2a) addWorkout(memberId, workout) — add a workout for a member.
 *       If the member doesn't exist, ignore the workout.
 *   2b) getAverageWorkoutDurations() — average duration per member.
 *       Return Map<Integer, Double>. Only include members with workouts.
 *
 * TASK 3: Implement getDuePayments() — tiered pricing:
 *   - BRONZE: 1st workout free, then $10/hour from 2nd onward
 *   - SILVER: first 3 free, then $8/hour from 4th onward
 *   - GOLD:   first 5 free, then $6/hour from 6th onward
 *   Workouts ordered by their ID.
 *   Duration rounded UP to nearest hour (80 min → 2 hours).
 *   Return Map<Integer, Integer>: memberId → total payment (ALL members).
 */

enum MembershipStatus {
    BRONZE, SILVER, GOLD
}

class Workout {
    private int id;
    private int startTime;  // minutes from start of day
    private int endTime;    // minutes from start of day

    public Workout(int id, int startTime, int endTime) {
        this.id = id;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public int getId() { return id; }
    public int getStartTime() { return startTime; }
    public int getEndTime() { return endTime; }
    public int getDuration() { return endTime - startTime; }
}

class Member {
    public int memberId;
    public String name;
    public MembershipStatus membershipStatus;

    public Member(int memberId, String name, MembershipStatus membershipStatus) {
        this.memberId = memberId;
        this.name = name;
        this.membershipStatus = membershipStatus;
    }

    @Override
    public String toString() {
        return "Member ID: " + memberId + ", Name: " + name +
               ", Status: " + membershipStatus;
    }
}

class MembershipStatistics {
    public int totalMembers;
    public int totalPaidMembers;
    public double conversionRate;

    public MembershipStatistics(int totalMembers, int totalPaidMembers,
                                double conversionRate) {
        this.totalMembers = totalMembers;
        this.totalPaidMembers = totalPaidMembers;
        this.conversionRate = conversionRate;
    }
}

class Membership {
    public List<Member> members;
    public Map<Integer,List<Workout>> map1 = new HashMap<>();

    public Membership() {
        members = new ArrayList<>();
    }

    public void addMember(Member member) {
        members.add(member);
    }

    public void updateMembership(int memberId, MembershipStatus status) {
        for (Member m : members) {
            if (m.memberId == memberId) {
                m.membershipStatus = status;
                break;
            }
        }
    }

    /**
     * TASK 1: This method has a bug. Find and fix it.
     * Returns statistics about the membership:
     * - totalMembers: number of members
     * - totalPaidMembers: members with SILVER or GOLD
     * - conversionRate: percentage of paid members (e.g., 66.67)
     */
    public MembershipStatistics getMembershipStatistics() {
        int totalMembers = members.size();
        int totalPaidMembers = 0;
        for (Member m : members) {
            if (m.membershipStatus == MembershipStatus.GOLD ||
                m.membershipStatus == MembershipStatus.SILVER) {
                totalPaidMembers++;
            }
        }
        double conversionRate = ((double)totalPaidMembers / (double)totalMembers) * 100.0;
        return new MembershipStatistics(totalMembers, totalPaidMembers, conversionRate);
    }

    /**
     * TASK 2a: Add a workout session for a member.
     * If the given member does not exist, ignore the workout.
     */
    public void addWorkout(int memberId, Workout workout) {
       for(Member m :members){
        if(m.memberId == memberId){
            List<Workout> w1 = map1.getOrDefault(memberId, new ArrayList<Workout>());
            w1.add(workout);
            map1.put(memberId, w1);
            break;
        }
       }
    }

    /**
     * TASK 2b: Calculate the average duration of workouts for each member.
     * Return Map<Integer, Double>: memberId → average duration in minutes.
     * Only include members who have at least one workout.
     */
    public Map<Integer, Double> getAverageWorkoutDurations() {
        Map<Integer,Double> map = new HashMap<>();
        for(Map.Entry<Integer,List<Workout>> entry1:map1.entrySet()){
            List<Workout> l1 = entry1.getValue();
            double ans = l1.stream().collect(Collectors.averagingDouble(e-> e.getDuration()));
            map.put(entry1.getKey(), ans);
        }
        return map;
    }

    /**
     * TASK 3: Calculate due payments for each member.
     *
     * BRONZE: 1st workout free, $10/hour from 2nd onward
     * SILVER: first 3 free, $8/hour from 4th onward
     * GOLD:   first 5 free, $6/hour from 6th onward
     *
     * Workouts ordered by ID. Duration rounded UP to nearest hour.
     * Return Map<Integer, Integer>: memberId → total payment.
     * Include ALL members (even those with $0 payment).
     */
    public Map<Integer, Integer> getDuePayments() {
        Map<Integer,Integer> map = new LinkedHashMap<>();
        int freeCount=0,rate=0;
        for(Member m1:members){
            List<Workout> l1 = map1.getOrDefault(m1.memberId,new ArrayList<>());
            l1.sort(Comparator.comparing(e-> e.getId()));
            int res = 0;
            if(m1.membershipStatus== MembershipStatus.BRONZE){
                freeCount = 1;
                rate = 10;
            }
            else if(m1.membershipStatus== MembershipStatus.SILVER){
                freeCount = 3;
                rate = 8;
            } 
            else{
                freeCount = 5;
                rate = 6;
            }
            for(int i=freeCount;i<l1.size();i++){
                res += (int)Math.ceil(l1.get(i).getDuration()/60.0)*rate;
            }
            map.put(m1.memberId,res);

            
        }
        return map;
    }
}

public class GymMembership {

    private static int passed = 0, failed = 0;

    public static void main(String[] args) {
        System.out.println("\n=== GYM MEMBERSHIP — KARAT PRACTICE ===\n");

        run("TASK 0 — Member basics", GymMembership::testMember);
        run("TASK 1 — Membership stats (FIX BUG)", GymMembership::testMembership);
        run("TASK 2 — Average workout durations", GymMembership::testGetAverageWorkoutDurations);
        run("TASK 3 — Due payments (tiered)", GymMembership::testGetDuePayments);

        System.out.println("\n--------------------------------------------------");
        System.out.println("Results: " + passed + " passed, " + failed + " failed out of " + (passed + failed));
    }

    public static void testMember() {
        Member m = new Member(1, "John Doe", MembershipStatus.BRONZE);
        assert m.memberId == 1 : "ID should be 1";
        assert m.name.equals("John Doe") : "Name should be John Doe";
        assert m.membershipStatus == MembershipStatus.BRONZE : "Status should be BRONZE";
    }

    public static void testMembership() {
        Membership gym = new Membership();
        gym.addMember(new Member(1, "John Doe", MembershipStatus.BRONZE));

        assert gym.members.size() == 1 :
            "Should have 1 member, was " + gym.members.size();

        gym.updateMembership(1, MembershipStatus.SILVER);
        assert gym.members.get(0).membershipStatus == MembershipStatus.SILVER :
            "Status should be SILVER after update, was " +
            gym.members.get(0).membershipStatus;

        gym.addMember(new Member(2, "Alex C", MembershipStatus.BRONZE));
        gym.addMember(new Member(3, "Marie C", MembershipStatus.GOLD));
        gym.addMember(new Member(4, "Joe D", MembershipStatus.SILVER));
        gym.addMember(new Member(5, "June R", MembershipStatus.BRONZE));
        gym.addMember(new Member(6, "Westley D", MembershipStatus.SILVER));

        MembershipStatistics stats = gym.getMembershipStatistics();
        assert stats.totalMembers == 6 :
            "Total should be 6, was " + stats.totalMembers;
        assert stats.totalPaidMembers == 4 :
            "Paid should be 4, was " + stats.totalPaidMembers;
        assert Math.abs(stats.conversionRate - 66.67) < 0.1 :
            "Rate should be ~66.67, was " + stats.conversionRate;
    }

    public static void testGetAverageWorkoutDurations() {
        Membership gym = new Membership();
        gym.addMember(new Member(12, "John Doe", MembershipStatus.SILVER));
        gym.addMember(new Member(22, "Alex Cleeve", MembershipStatus.BRONZE));
        gym.addMember(new Member(31, "Marie Cardiff", MembershipStatus.GOLD));
        gym.addMember(new Member(37, "George Costanza", MembershipStatus.SILVER));

        gym.addWorkout(12, new Workout(11, 10, 20));     // 10 min
        gym.addWorkout(22, new Workout(24, 15, 35));     // 20 min
        gym.addWorkout(31, new Workout(32, 45, 90));     // 45 min
        gym.addWorkout(12, new Workout(47, 100, 155));   // 55 min
        gym.addWorkout(22, new Workout(56, 120, 200));   // 80 min
        gym.addWorkout(31, new Workout(62, 300, 400));   // 100 min
        gym.addWorkout(12, new Workout(78, 1000, 1010)); // 10 min
        gym.addWorkout(4,  new Workout(80, 1010, 1045)); // IGNORED — member 4 doesn't exist

        Map<Integer, Double> avg = gym.getAverageWorkoutDurations();

        assert Math.abs(avg.get(12) - 25.0) < 0.1 :
            "Member 12 avg should be 25.0, was " + avg.get(12);
        assert Math.abs(avg.get(22) - 50.0) < 0.1 :
            "Member 22 avg should be 50.0, was " + avg.get(22);
        assert Math.abs(avg.get(31) - 72.5) < 0.1 :
            "Member 31 avg should be 72.5, was " + avg.get(31);
        assert !avg.containsKey(37) :
            "Member 37 should not be in map (no workouts)";
        assert !avg.containsKey(4) :
            "Member 4 should not be in map (doesn't exist)";
    }

    public static void testGetDuePayments() {
        Membership gym = new Membership();
        gym.addMember(new Member(1, "Bronze Ben", MembershipStatus.BRONZE));
        gym.addMember(new Member(2, "Silver Sam", MembershipStatus.SILVER));
        gym.addMember(new Member(3, "Gold Grace", MembershipStatus.GOLD));
        gym.addMember(new Member(4, "Bronze Bea", MembershipStatus.BRONZE)); // no workouts

        // Member 1 (BRONZE): 3 workouts — 1st free, 2nd+3rd charged $10/hr
        gym.addWorkout(1, new Workout(1, 0, 60));      // 60min = 1hr → FREE
        gym.addWorkout(1, new Workout(2, 100, 180));    // 80min → ceil=2hrs → $20
        gym.addWorkout(1, new Workout(3, 200, 320));    // 120min = 2hrs → $20
        // Expected: $40

        // Member 2 (SILVER): 5 workouts — first 3 free, 4th+5th charged $8/hr
        gym.addWorkout(2, new Workout(4, 0, 30));       // 30min → FREE
        gym.addWorkout(2, new Workout(5, 60, 105));     // 45min → FREE
        gym.addWorkout(2, new Workout(6, 120, 180));    // 60min → FREE
        gym.addWorkout(2, new Workout(7, 200, 290));    // 90min → ceil=2hrs → $16
        gym.addWorkout(2, new Workout(8, 300, 350));    // 50min → ceil=1hr → $8
        // Expected: $24

        // Member 3 (GOLD): 7 workouts — first 5 free, 6th+7th charged $6/hr
        gym.addWorkout(3, new Workout(9, 0, 60));       // FREE
        gym.addWorkout(3, new Workout(10, 70, 130));    // FREE
        gym.addWorkout(3, new Workout(11, 140, 200));   // FREE
        gym.addWorkout(3, new Workout(12, 210, 270));   // FREE
        gym.addWorkout(3, new Workout(13, 280, 340));   // FREE
        gym.addWorkout(3, new Workout(14, 350, 420));   // 70min → ceil=2hrs → $12
        gym.addWorkout(3, new Workout(15, 430, 490));   // 60min = 1hr → $6
        // Expected: $18

        // Member 4 (BRONZE): no workouts → $0

        Map<Integer, Integer> payments = gym.getDuePayments();

        assert payments.get(1) == 40 :
            "Member 1 (BRONZE) should owe $40, was " + payments.get(1);
        assert payments.get(2) == 24 :
            "Member 2 (SILVER) should owe $24, was " + payments.get(2);
        assert payments.get(3) == 18 :
            "Member 3 (GOLD) should owe $18, was " + payments.get(3);
        assert payments.get(4) == 0 :
            "Member 4 (no workouts) should owe $0, was " + payments.get(4);
    }

    private static void run(String name, Runnable test) {
        try {
            test.run();
            passed++;
            System.out.println("  PASS: " + name);
        } catch (Exception | AssertionError e) {
            failed++;
            System.out.println("  FAIL: " + name + " -> " + e.getMessage());
        }
    }

    /*
     * ================================================================
     *                      ANSWER KEY
     * ================================================================
     *
     *  TASK 1: Bug Fix — Integer Division
     *  ────────────────────────────────────
     *  BUG:  double conversionRate = (totalPaidMembers / totalMembers) * 100.0;
     *        // int / int = 0 (truncated), then 0 * 100.0 = 0.0
     *
     *  FIX:  double conversionRate = (totalPaidMembers / (double) totalMembers) * 100.0;
     *        // Cast one operand to double → forces floating-point division
     *
     *
     *  TASK 2a: addWorkout
     *  ────────────────────
     *  // Declare as class field in Membership:
     *  Map<Integer, List<Workout>> workoutMap = new HashMap<>();
     *
     *  public void addWorkout(int memberId, Workout workout) {
     *      boolean exists = false;
     *      for (Member m : members) {
     *          if (m.memberId == memberId) { exists = true; break; }
     *      }
     *      if (!exists) return;
     *      workoutMap.computeIfAbsent(memberId, k -> new ArrayList<>()).add(workout);
     *  }
     *
     *
     *  TASK 2b: getAverageWorkoutDurations
     *  ─────────────────────────────────────
     *  public Map<Integer, Double> getAverageWorkoutDurations() {
     *      Map<Integer, Double> result = new HashMap<>();
     *      for (Map.Entry<Integer, List<Workout>> entry : workoutMap.entrySet()) {
     *          List<Workout> workouts = entry.getValue();
     *          double total = 0;
     *          for (Workout w : workouts) {
     *              total += w.getDuration();
     *          }
     *          result.put(entry.getKey(), total / workouts.size());
     *      }
     *      return result;
     *  }
     *
     *
     *  TASK 3: getDuePayments
     *  ───────────────────────
     *  public Map<Integer, Integer> getDuePayments() {
     *      Map<Integer, Integer> payments = new HashMap<>();
     *      for (Member member : members) {
     *          List<Workout> workouts = new ArrayList<>(
     *              workoutMap.getOrDefault(member.memberId, new ArrayList<>()));
     *          workouts.sort(Comparator.comparingInt(Workout::getId));
     *
     *          int freeCount, rate;
     *          switch (member.membershipStatus) {
     *              case SILVER: freeCount = 3; rate = 8;  break;
     *              case GOLD:   freeCount = 5; rate = 6;  break;
     *              default:     freeCount = 1; rate = 10; break;
     *          }
     *
     *          int total = 0;
     *          for (int i = freeCount; i < workouts.size(); i++) {
     *              int mins = workouts.get(i).getDuration();
     *              int hours = (int) Math.ceil(mins / 60.0);
     *              total += hours * rate;
     *          }
     *          payments.put(member.memberId, total);
     *      }
     *      return payments;
     *  }
     *
     * ================================================================
     */
}
