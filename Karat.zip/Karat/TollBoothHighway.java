import java.util.*;
import java.util.stream.*;

/**
 * =====================================================================
 * TOLL BOOTH HIGHWAY — Karat Coding Problem
 * =====================================================================
 *
 * We are writing software to analyze logs for toll booths on a highway.
 * This highway is a divided highway with limited access; the only way on
 * or off the highway is through a toll booth.
 *
 * There are three types of toll booths:
 *   ENTRY  — where a car goes through a booth as it enters the highway
 *   EXIT   — where a car goes through a booth as it exits the highway
 *   MAINROAD (M) — sensors that record a license plate as a car drives
 *                   through at full speed
 *
 *       Exit Booth           Entry Booth
 *           |                    |
 *   --------X--------------------X--------
 *        /                          \
 *       /            M               \
 *   ---X-------------X---------------X---
 *       \                            /
 *        \                          /
 *   ------X------------------------X------
 *           |                    |
 *       Entry Booth           Exit Booth
 *
 * The log entries look like:
 *   ["ENTRY", "ABC123", "2023-06-25 10:00:00"]
 *   ["M",     "ABC123", "2023-06-25 10:05:00"]
 *   ["EXIT",  "ABC123", "2023-06-25 10:30:00"]
 *
 * TASK 1: Read through code, find and fix the bug, run the tests.
 * TASK 2: Implement findMismatchedEntries() — find cars that entered
 *         but never exited, or exited but never entered.
 * TASK 3: Implement getAverageTripTime() — average time on highway.
 */

class TollBoothLog {
    String type;       // "ENTRY", "EXIT", or "M"
    String plate;      // license plate number
    String timestamp;  // e.g., "2023-06-25 10:00:00"

    public TollBoothLog(String type, String plate, String timestamp) {
        this.type = type;
        this.plate = plate;
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "[" + type + ", " + plate + ", " + timestamp + "]";
    }
}

class HighwayTracker {
    List<TollBoothLog> logs;

    public HighwayTracker() {
        this.logs = new ArrayList<>();
    }

    public void addLog(String type, String plate, String timestamp) {
        logs.add(new TollBoothLog(type, plate, timestamp));
    }

    /**
     * TASK 1: Return a Set of all unique license plates seen in the logs.
     *
     * ❌ BROKEN VERSION (for practice — find the bug):
     *   public Set<String> getUniquePlates() {
     *       List<String> plates = new ArrayList<>();
     *       for (TollBoothLog log : logs) {
     *           plates.add(log.plate);
     *       }
     *       return plates;  // BUG: returning List, not Set — no dedup
     *   }
     */
    // ✅ FIXED VERSION:
    public Set<String> getUniquePlates() {
        Set<String> plates = new HashSet<>();
        for (TollBoothLog log : logs) {
            plates.add(log.plate);
        }
        return plates;
    }

    /**
     * TASK 2: Find mismatched entries.
     * Return a Map where:
     *   key = license plate
     *   value = "NO_EXIT" if the car entered but never exited
     *           "NO_ENTRY" if the car exited but never entered
     *
     * Only consider ENTRY and EXIT logs (ignore MAINROAD "M" logs).
     *
     * ❌ BROKEN VERSION (3 bugs — find them!):
     *   public Map<String, String> findMismatchedEntries() {
     *       Set<String> entered = new HashSet<>();
     *       Set<String> exited = new HashSet<>();
     *
     *       for (TollBoothLog log : logs) {
     *           if (log.type == "ENTRY") {               // BUG 1: == instead of .equals()
     *               entered.add(log.plate);
     *           } else if ("EXIT".equals(log.type)) {
     *               exited.add(log.plate);
     *           } else {                                  // BUG 2: doesn't ignore "M" — adds M plates to exited
     *               exited.add(log.plate);
     *           }
     *       }
     *
     *       Map<String, String> mismatches = new HashMap<>();
     *
     *       for (String plate : entered) {
     *           if (!exited.contains(plate)) {
     *               mismatches.put(plate, "NO_EXIT");
     *           }
     *       }
     *
     *       for (String plate : exited) {
     *           if (!entered.contains(plate)) {
     *               mismatches.put(plate, "NO_EXIT");    // BUG 3: should be "NO_ENTRY"
     *           }
     *       }
     *
     *       return mismatches;
     *   }
     */
    // ✅ FIXED VERSION:
    public Map<String, String> findMismatchedEntries() {
        Set<String> entered = new HashSet<>();
        Set<String> exited = new HashSet<>();

        for (TollBoothLog log : logs) {
            if ("ENTRY".equals(log.type)) {
                entered.add(log.plate);
            } else if ("EXIT".equals(log.type)) {
                exited.add(log.plate);
            }
            // Ignore "M" type
        }

        Map<String, String> mismatches = new HashMap<>();

        // Cars that entered but never exited
        for (String plate : entered) {
            if (!exited.contains(plate)) {
                mismatches.put(plate, "NO_EXIT");
            }
        }

        // Cars that exited but never entered
        for (String plate : exited) {
            if (!entered.contains(plate)) {
                mismatches.put(plate, "NO_ENTRY");
            }
        }

        return mismatches;
    }

    /**
     * TASK 3: Get the count of cars currently on the highway.
     * A car is "on the highway" if it has an ENTRY but no corresponding EXIT
     * that came after it (by timestamp order, which we assume is log order).
     *
     * ❌ BROKEN VERSION (3 bugs — find them!):
     *   public int getCarsOnHighway() {
     *       Map<String, Integer> onHighway = new HashMap<>();
     *
     *       for (TollBoothLog log : logs) {
     *           if ("ENTRY".equals(log.type)) {
     *               onHighway.put(log.plate, 1);             // BUG 1: always sets 1, doesn't handle re-entry
     *           } else if ("EXIT".equals(log.type)) {
     *               onHighway.remove(log.plate);              // BUG 2: removes entirely instead of decrementing
     *           }
     *       }
     *
     *       return onHighway.size();                          // BUG 3: counts plates, not car count values
     *   }                                                     // (works if no re-entry, but wrong approach)
     */
    // ✅ FIXED VERSION:
    public int getCarsOnHighway() {
        Map<String, Integer> onHighway = new HashMap<>();

        for (TollBoothLog log : logs) {
            if ("ENTRY".equals(log.type)) {
                onHighway.put(log.plate, onHighway.getOrDefault(log.plate, 0) + 1);
            } else if ("EXIT".equals(log.type)) {
                int count = onHighway.getOrDefault(log.plate, 0);
                if (count > 0) {
                    onHighway.put(log.plate, count - 1);
                }
            }
        }

        return onHighway.values().stream().mapToInt(Integer::intValue).sum();
    }

    /**
     * TASK 4 (Bonus): For each car that has both ENTRY and EXIT,
     * compute how many MAINROAD sensors it passed.
     * Returns Map: plate -> count of M logs between entry and exit.
     *
     * ❌ BROKEN VERSION (3 bugs — find them!):
     *   public Map<String, Integer> getMainroadPassCount() {
     *       Set<String> onHighway = new HashSet<>();
     *       Map<String, Integer> passCount = new HashMap<>();
     *
     *       for (TollBoothLog log : logs) {
     *           if ("ENTRY".equals(log.type)) {
     *               onHighway.add(log.plate);
     *               passCount.put(log.plate, 0);             // BUG 1: resets count if car re-enters!
     *           } else if ("M".equals(log.type)) {           // BUG 2: doesn't check if car is on highway
     *               passCount.put(log.plate, passCount.get(log.plate) + 1);  // BUG 3: NPE if plate not in map
     *           } else if ("EXIT".equals(log.type)) {
     *               onHighway.remove(log.plate);
     *           }
     *       }
     *
     *       return passCount;
     *   }
     */
    // ✅ FIXED VERSION:
    public Map<String, Integer> getMainroadPassCount() {
        // Track: for each plate, whether they're currently on the highway
        Set<String> onHighway = new HashSet<>();
        Map<String, Integer> passCount = new HashMap<>();

        for (TollBoothLog log : logs) {
            if ("ENTRY".equals(log.type)) {
                onHighway.add(log.plate);
                passCount.putIfAbsent(log.plate, 0);
            } else if ("M".equals(log.type) && onHighway.contains(log.plate)) {
                passCount.put(log.plate, passCount.getOrDefault(log.plate, 0) + 1);
            } else if ("EXIT".equals(log.type)) {
                onHighway.remove(log.plate);
            }
        }

        return passCount;
    }
}

public class TollBoothHighway {
    public static void main(String[] args) {
        testGetUniquePlates();
        testFindMismatchedEntries();
        testGetCarsOnHighway();
        testGetMainroadPassCount();
        System.out.println("All Toll Booth tests passed!");
    }

    static HighwayTracker createSampleTracker() {
        HighwayTracker tracker = new HighwayTracker();
        // Car ABC123: enters and exits normally
        tracker.addLog("ENTRY", "ABC123", "2023-06-25 10:00:00");
        tracker.addLog("M",     "ABC123", "2023-06-25 10:05:00");
        tracker.addLog("M",     "ABC123", "2023-06-25 10:15:00");
        tracker.addLog("EXIT",  "ABC123", "2023-06-25 10:30:00");

        // Car DEF456: enters but never exits (still on highway)
        tracker.addLog("ENTRY", "DEF456", "2023-06-25 10:10:00");
        tracker.addLog("M",     "DEF456", "2023-06-25 10:20:00");

        // Car GHI789: exits but never entered (data anomaly)
        tracker.addLog("EXIT",  "GHI789", "2023-06-25 10:45:00");

        // Car JKL012: enters and exits
        tracker.addLog("ENTRY", "JKL012", "2023-06-25 11:00:00");
        tracker.addLog("EXIT",  "JKL012", "2023-06-25 11:45:00");

        return tracker;
    }

    static void testGetUniquePlates() {
        System.out.println("Running testGetUniquePlates");
        HighwayTracker tracker = createSampleTracker();
        Set<String> plates = tracker.getUniquePlates();
        assert plates.size() == 4 : "Should have 4 unique plates, got " + plates.size();
        assert plates.contains("ABC123") : "Should contain ABC123";
        assert plates.contains("DEF456") : "Should contain DEF456";
        assert plates.contains("GHI789") : "Should contain GHI789";
        assert plates.contains("JKL012") : "Should contain JKL012";
    }

    static void testFindMismatchedEntries() {
        System.out.println("Running testFindMismatchedEntries");
        HighwayTracker tracker = createSampleTracker();
        Map<String, String> mismatches = tracker.findMismatchedEntries();
        assert mismatches.size() == 2 : "Should have 2 mismatches, got " + mismatches.size();
        assert "NO_EXIT".equals(mismatches.get("DEF456")) :
            "DEF456 should be NO_EXIT, was " + mismatches.get("DEF456");
        assert "NO_ENTRY".equals(mismatches.get("GHI789")) :
            "GHI789 should be NO_ENTRY, was " + mismatches.get("GHI789");
    }

    static void testGetCarsOnHighway() {
        System.out.println("Running testGetCarsOnHighway");
        HighwayTracker tracker = createSampleTracker();
        int count = tracker.getCarsOnHighway();
        // ABC123 entered & exited, DEF456 entered (still on), GHI789 exited only, JKL012 entered & exited
        assert count == 1 : "Should have 1 car on highway (DEF456), got " + count;
    }

    static void testGetMainroadPassCount() {
        System.out.println("Running testGetMainroadPassCount");
        HighwayTracker tracker = createSampleTracker();
        Map<String, Integer> passes = tracker.getMainroadPassCount();
        assert passes.get("ABC123") == 2 : "ABC123 should have 2 M passes, got " + passes.get("ABC123");
        assert passes.get("DEF456") == 1 : "DEF456 should have 1 M pass, got " + passes.get("DEF456");
        assert passes.getOrDefault("JKL012", 0) == 0 :
            "JKL012 should have 0 M passes";
    }
}
