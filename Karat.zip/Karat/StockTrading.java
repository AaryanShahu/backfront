import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.*;

/**
 * =====================================================================
 * STOCK TRADING — Karat Coding Problem
 * =====================================================================
 *
 * We are developing a stock trading data management software that tracks
 * the prices of different stocks over time and provides useful statistics.
 *
 * The program includes three classes: Stock, PriceRecord, StockCollection.
 *
 * Classes:
 *   Stock           — data about a particular stock (symbol, name)
 *   PriceRecord     — a single price record for a stock (date, price)
 *   StockCollection — manages price records for a particular stock
 *
 * TASK 1: Read the code. The test for StockCollection is not passing
 *         due to a bug. Find and fix the bug.
 *
 * TASK 2: Add "getBiggestChange" to StockCollection. This function
 *         calculates and returns the largest change in stock price between
 *         any two consecutive days in the price records of a stock, along
 *         with the dates of the change in a list.
 *
 * Example: Price records for a stock:
 *   Price:  110   112    90   105
 *   Date:  2023-06-29  2023-07-01  2023-06-25  2023-07-06
 *
 * Stock price changes (sorted based on date):
 *   Date:  2023-06-25 → 2023-06-29 → 2023-07-01 → 2023-07-06
 *   Price:     90    →    110     →     112     →     105
 *   Change:       +20          +2           -7
 *
 * Biggest change: 20 (from 2023-06-25 to 2023-06-29)
 */

class Stock {
    /** Data about a particular stock. */
    String symbol;  // String, the symbol of the stock
    String name;    // String, the name of the stock

    public Stock(String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (other == null || !(other instanceof Stock)) return false;
        Stock stock = (Stock) other;
        return symbol.equals(stock.symbol) && name.equals(stock.name);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(symbol, name);
    }
}

class PriceRecord implements Comparable<PriceRecord> {
    String date;    // format: "yyyy-MM-dd"
    double price;   // price on that date

    public PriceRecord(String date, double price) {
        this.date = date;
        this.price = price;
    }

    @Override
    public int compareTo(PriceRecord other) {
        return this.date.compareTo(other.date);  // Sort by date ascending
    }

    @Override
    public String toString() {
        return "[" + date + ": $" + price + "]";
    }
}

class StockCollection {
    Stock stock;
    List<PriceRecord> records;

    public StockCollection(Stock stock) {
        this.stock = stock;
        this.records = new ArrayList<>();
    }

    public void addRecord(String date, double price) {
        records.add(new PriceRecord(date, price));
    }

    public int getRecordCount() {
        return records.size();
    }

    /**
     * Returns the highest price across all records.
     *
     * ❌ BROKEN VERSION (for practice):
     *   public double getHighestPrice() {
     *       double highest = 0;
     *       for (PriceRecord record : records) {
     *           if (record.price < highest) {  // BUG: < should be >
     *               highest = record.price;
     *           }
     *       }
     *       return highest;
     *   }
     */
    // ✅ FIXED VERSION:
    public double getHighestPrice() {
        if (records == null || records.isEmpty()) return 0.0;
        double highest = Double.MIN_VALUE;
        for (PriceRecord record : records) {
            if (record.price > highest) {  // FIX: > not <
                highest = record.price;
            }
        }
        return highest;
    }

    /**
     * Returns the lowest price across all records.
     */
    public double getLowestPrice() {
        if (records == null || records.isEmpty()) return 0.0;
        return records.stream()
            .mapToDouble(r -> r.price)
            .min()
            .orElse(Double.MAX_VALUE);
    }

    /**
     * Returns the average price across all records.
     *
     * ❌ BROKEN VERSION (another common bug):
     *   public double getAveragePrice() {
     *       int total = 0;  // BUG: int instead of double, truncates decimals
     *       for (PriceRecord record : records) {
     *           total += record.price;
     *       }
     *       return total / records.size();  // BUG: integer division
     *   }
     */
    // ✅ FIXED VERSION:
    public double getAveragePrice() {
        if (records == null || records.isEmpty()) return 0.0;
        double total = 0.0;  // FIX: use double
        for (PriceRecord record : records) {
            total += record.price;
        }
        return total / records.size();
    }

    /**
     * TASK 2: getBiggestChange
     *
     * Find the largest absolute change in price between any two
     * consecutive days (sorted by date).
     *
     * Returns a Map with:
     *   "fromDate"  → the earlier date
     *   "toDate"    → the later date
     *   "change"    → the absolute price change (as String)
     *
     * Steps:
     *   1. Sort records by date
     *   2. Iterate over consecutive pairs
     *   3. Track the pair with the largest absolute change
     */
    public Map<String, String> getBiggestChange() {
        if (records == null || records.size() < 2) {
            return Collections.emptyMap();
        }

        // Step 1: Sort by date
        List<PriceRecord> sorted = new ArrayList<>(records);
        Collections.sort(sorted);  // uses PriceRecord.compareTo (by date)

        // Step 2: Find biggest change between consecutive days
        double biggestChange = 0;
        int biggestIndex = 0;

        for (int i = 1; i < sorted.size(); i++) {
            double change = Math.abs(sorted.get(i).price - sorted.get(i - 1).price);
            if (change > biggestChange) {
                biggestChange = change;
                biggestIndex = i;
            }
        }

        // Step 3: Return result
        Map<String, String> result = new HashMap<>();
        result.put("fromDate", sorted.get(biggestIndex - 1).date);
        result.put("toDate", sorted.get(biggestIndex).date);
        result.put("change", String.valueOf(biggestChange));
        return result;
    }

    /**
     * BONUS: Get all price changes between consecutive days, sorted by date.
     * Returns list of maps with fromDate, toDate, change.
     */
    public List<Map<String, String>> getAllChanges() {
        List<PriceRecord> sorted = new ArrayList<>(records);
        Collections.sort(sorted);

        List<Map<String, String>> changes = new ArrayList<>();
        for (int i = 1; i < sorted.size(); i++) {
            double change = sorted.get(i).price - sorted.get(i - 1).price;
            Map<String, String> entry = new HashMap<>();
            entry.put("fromDate", sorted.get(i - 1).date);
            entry.put("toDate", sorted.get(i).date);
            entry.put("change", String.valueOf(change));
            changes.add(entry);
        }
        return changes;
    }
}

public class StockTrading {
    public static void main(String[] args) {
        testStockCollection();
        testGetHighestPrice();
        testGetAveragePrice();
        testGetBiggestChange();
        testGetBiggestChangeLarger();
        testEdgeCases();
        System.out.println("All Stock Trading tests passed!");
    }

    // Helper to create a sample StockCollection
    static StockCollection createSampleCollection() {
        Stock apple = new Stock("AAPL", "Apple Inc");
        StockCollection collection = new StockCollection(apple);
        // Note: dates are NOT in order — this tests sorting!
        collection.addRecord("2023-06-29", 110);
        collection.addRecord("2023-07-01", 112);
        collection.addRecord("2023-06-25", 90);
        collection.addRecord("2023-07-06", 105);
        return collection;
    }

    static void testStockCollection() {
        System.out.println("Running testStockCollection");
        StockCollection collection = createSampleCollection();
        assert collection.getRecordCount() == 4 :
            "Should have 4 records, got " + collection.getRecordCount();
    }

    static void testGetHighestPrice() {
        System.out.println("Running testGetHighestPrice");
        StockCollection collection = createSampleCollection();
        // Prices: 110, 112, 90, 105 — highest = 112
        assert collection.getHighestPrice() == 112 :
            "Highest price should be 112, was " + collection.getHighestPrice();
    }

    static void testGetAveragePrice() {
        System.out.println("Running testGetAveragePrice");
        StockCollection collection = createSampleCollection();
        // (110 + 112 + 90 + 105) / 4 = 417 / 4 = 104.25
        double avg = collection.getAveragePrice();
        assert Math.abs(avg - 104.25) < 0.01 :
            "Average should be 104.25, was " + avg;
    }

    static void testGetBiggestChange() {
        System.out.println("Running testGetBiggestChange");
        StockCollection collection = createSampleCollection();

        // Sorted by date:
        //   2023-06-25: $90
        //   2023-06-29: $110  → change = |110 - 90| = 20
        //   2023-07-01: $112  → change = |112 - 110| = 2
        //   2023-07-06: $105  → change = |105 - 112| = 7
        // Biggest = 20.0, from 2023-06-25 to 2023-06-29

        Map<String, String> result = collection.getBiggestChange();
        assert "2023-06-25".equals(result.get("fromDate")) :
            "fromDate should be 2023-06-25, was " + result.get("fromDate");
        assert "2023-06-29".equals(result.get("toDate")) :
            "toDate should be 2023-06-29, was " + result.get("toDate");
        assert "20.0".equals(result.get("change")) :
            "change should be 20.0, was " + result.get("change");
    }

    static void testGetBiggestChangeLarger() {
        System.out.println("Running testGetBiggestChangeLarger");
        Stock msft = new Stock("MSFT", "Microsoft");
        StockCollection collection = new StockCollection(msft);
        collection.addRecord("2023-01-01", 100);
        collection.addRecord("2023-01-02", 105);
        collection.addRecord("2023-01-03", 80);  // big drop of 25
        collection.addRecord("2023-01-04", 82);

        Map<String, String> result = collection.getBiggestChange();
        assert "2023-01-02".equals(result.get("fromDate")) :
            "fromDate should be 2023-01-02, was " + result.get("fromDate");
        assert "2023-01-03".equals(result.get("toDate")) :
            "toDate should be 2023-01-03, was " + result.get("toDate");
        assert "25.0".equals(result.get("change")) :
            "change should be 25.0, was " + result.get("change");
    }

    static void testEdgeCases() {
        System.out.println("Running testEdgeCases");

        // Edge: only 1 record
        Stock stock = new Stock("TEST", "Test");
        StockCollection rc = new StockCollection(stock);
        rc.addRecord("2023-01-01", 100);
        Map<String, String> result = rc.getBiggestChange();
        assert result.isEmpty() : "Single record should return empty map";

        // Edge: empty collection
        StockCollection empty = new StockCollection(stock);
        assert empty.getBiggestChange().isEmpty() : "Empty collection should return empty map";
        assert empty.getLowestPrice() == Double.MAX_VALUE : "Empty lowest should be MAX_VALUE";

        // Edge: two records
        StockCollection two = new StockCollection(stock);
        two.addRecord("2023-01-01", 50);
        two.addRecord("2023-01-02", 75);
        Map<String, String> result2 = two.getBiggestChange();
        assert "25.0".equals(result2.get("change")) : "Two records change should be 25.0";
    }
}
