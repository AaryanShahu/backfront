import java.util.*;
import java.util.stream.*;
import org.junit.*;

/**
 * =====================================================================
 * STOCK TRADING — Karat Coding Problem
 * =====================================================================
 *
 * We are developing a stock trading data management software that tracks
 * the prices of different stocks over time and provides useful statistics.
 *
 * The program includes three classes: Stock, PriceRecord, StockCollection.
 *
 * Classes:
 *   Stock           — data about a particular stock (symbol, name)
 *   PriceRecord     — a single price record for a stock (date, price)
 *   StockCollection — manages price records for a particular stock
 *
 * TASK 1: Read the code. The test for StockCollection is not passing
 *         due to a bug. Find and fix the bug.
 *
 * TASK 2: Add "getBiggestChange" to StockCollection. This function
 *         calculates and returns the largest change in stock price between
 *         any two consecutive days in the price records of a stock, along
 *         with the dates of the change in a list.
 *
 * Example: Price records for a stock:
 *   Price:  110   112    90   105
 *   Date:  2023-06-29  2023-07-01  2023-06-25  2023-07-06
 *
 * Stock price changes (sorted based on date):
 *   Date:  2023-06-25 → 2023-06-29 → 2023-07-01 → 2023-07-06
 *   Price:     90    →    110     →     112     →     105
 *   Change:       +20          +2           -7
 *
 * Biggest change: 20 (from 2023-06-25 to 2023-06-29)
 */

class Stock {
    String symbol;
    String name;

    Stock(String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (other == null || getClass() != other.getClass()) return false;
        Stock stock = (Stock) other;
        return symbol.equals(stock.symbol) && name.equals(stock.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(symbol, name);
    }
}

class PriceRecord {
    Stock stock;
    int price;
    String date; // "YYYY-MM-DD"

    PriceRecord(Stock stock, int price, String date) {
        this.stock = stock;
        this.price = price;
        this.date = date;
    }
}

class StockCollection {
    ArrayList<PriceRecord> priceRecords = new ArrayList<>();
    Stock stock;

    StockCollection(Stock stock) {
        this.stock = stock;
    }

    int getNumPriceRecords() {
        if (priceRecords == null || priceRecords.isEmpty()) {
            return 0;
        }
        return priceRecords.size();
    }

    void addPriceRecord(PriceRecord priceRecord) {
        if (!priceRecord.stock.equals(this.stock)) {
            throw new IllegalArgumentException("PriceRecord's Stock is not the same as the StockCollection's");
        }
        priceRecords.add(priceRecord);
    }

    /*
     * BUG 1 & 2 (original):
     *   int getMaxPrice() {
     *       return priceRecords.stream().mapToInt(record -> record.price).max();
     *   }
     *   int getMinPrice() {
     *       return priceRecords.stream().mapToInt(record -> record.price).min();
     *   }
     *
     * PROBLEM: .max() and .min() return OptionalInt, NOT int.
     *   - Won't compile: "incompatible types: OptionalInt cannot be converted to int"
     *   - Also: if priceRecords is empty, there's no max/min → need a default.
     *
     * FIX: Add .orElse(-1) to unwrap OptionalInt and provide a default for empty list.
     *       Could also add a null check: if (priceRecords == null || priceRecords.isEmpty()) return -1;
     */
    int getMaxPrice() {
        return priceRecords.stream().mapToInt(r -> r.price).max().orElse(-1);
    }

    int getMinPrice() {
        return priceRecords.stream().mapToInt(r -> r.price).min().orElse(-1);
    }

    /*
     * BUG 3 (original):
     *   double getAvgPrice() {
     *       double total = priceRecords.stream().mapToInt(record -> record.price).sum();
     *       return total / priceRecords.size();
     *   }
     *
     * PROBLEM: No empty-list check → divides by 0 when priceRecords is empty.
     *   - Test expects -1.0 for empty collection, but 0/0 = NaN.
     *
     * FIX: Add null/empty check returning -1.0 before the calculation.
     *       if (priceRecords == null || priceRecords.isEmpty()) return -1.0;
     */
    double getAvgPrice() {
        if (priceRecords.isEmpty()) {
            return -1.0;
        }
        double total = priceRecords.stream().mapToInt(r -> r.price).sum();
        return total / priceRecords.size();
    }

    public Object[] getBiggestChange() {
        if (priceRecords.size() < 2) {
            return null;
        }

        List<PriceRecord> sorted = new ArrayList<>(priceRecords);
        sorted.sort(Comparator.comparing(r -> r.date));

        int biggestChange = 0;
        int index = 0;

        for (int i = 1; i < sorted.size(); i++) {
            int change = sorted.get(i).price - sorted.get(i - 1).price;
            if (Math.abs(change) > Math.abs(biggestChange)) {
                biggestChange = change;
                index = i;
            }
        }

        return new Object[]{
            biggestChange,
            sorted.get(index - 1).date,
            sorted.get(index).date
        };
    }

    /**
     * BONUS: Get all price changes between consecutive days, sorted by date.
     * Returns list of Object[] where each entry is {change, fromDate, toDate}.
     */
    public List<Object[]> getAllChanges() {
        if (priceRecords == null || priceRecords.size() < 2) {
            return Collections.emptyList();
        }

        List<PriceRecord> sorted = new ArrayList<>(priceRecords);
        sorted.sort(Comparator.comparing(r -> r.date));

        List<Object[]> changes = new ArrayList<>();
        for (int i = 1; i < sorted.size(); i++) {
            int change = sorted.get(i).price - sorted.get(i - 1).price;
            changes.add(new Object[]{
                change,
                sorted.get(i - 1).date,
                sorted.get(i).date
            });
        }
        return changes;
    }
}

public class StockTradingKarat {

    public static void main(String[] args) {
        testPriceRecord();
        testStockCollection();
        testGetBiggestChange();
        testGetAllChanges();
        System.out.println("\nAll tests passed!");
    }

    public static void testPriceRecord() {
        System.out.println("Running testPriceRecord");
        Stock testStock = new Stock("AAPL", "Apple Inc.");
        PriceRecord pr = new PriceRecord(testStock, 100, "2023-07-01");

        Assert.assertEquals(pr.stock, testStock);
        Assert.assertEquals(pr.price, 100);
        Assert.assertEquals(pr.date, "2023-07-01");
    }

    private static StockCollection makeStockCollection(Stock stock, Object[][] priceData) {
        StockCollection sc = new StockCollection(stock);
        for (Object[] row : priceData) {
            sc.addPriceRecord(new PriceRecord(stock, (int) row[0], (String) row[1]));
        }
        return sc;
    }

    public static void testStockCollection() {
        System.out.println("Running testStockCollection");
        Stock testStock = new Stock("AAPL", "Apple Inc.");
        StockCollection sc = new StockCollection(testStock);

        Assert.assertEquals(0, sc.getNumPriceRecords());
        Assert.assertEquals(-1, sc.getMaxPrice());
        Assert.assertEquals(-1, sc.getMinPrice());
        Assert.assertEquals(-1.0, sc.getAvgPrice(), 0.001);

        Object[][] priceData = {
            {110, "2023-06-29"}, {112, "2023-07-01"},
            {90, "2023-06-28"}, {105, "2023-07-06"}
        };
        sc = makeStockCollection(testStock, priceData);

        Assert.assertEquals(priceData.length, sc.getNumPriceRecords());
        Assert.assertEquals(112, sc.getMaxPrice());
        Assert.assertEquals(90, sc.getMinPrice());
        Assert.assertEquals(104.25, sc.getAvgPrice(), 0.1);
    }

    public static void testGetBiggestChange() {
        System.out.println("Running testGetBiggestChange");
        Stock testStock = new Stock("AAPL", "Apple Inc.");
        StockCollection sc = new StockCollection(testStock);

        Assert.assertNull(sc.getBiggestChange());

        // Sorted: 90→110(+20), 110→112(+2), 112→105(-7) → biggest = +20
        Object[][] priceData = {
            {110, "2023-06-29"}, {112, "2023-07-01"},
            {90, "2023-06-25"}, {105, "2023-07-06"}
        };
        sc = makeStockCollection(testStock, priceData);
        Assert.assertArrayEquals(
            new Object[]{20, "2023-06-25", "2023-06-29"},
            sc.getBiggestChange()
        );

        // Sorted: 210→180(-30), 180→190(+10), 190→200(+10) → biggest = -30
        Object[][] priceData2 = {
            {200, "2000-01-04"}, {210, "1999-12-30"},
            {190, "2000-01-03"}, {180, "2000-01-01"}
        };
        sc = makeStockCollection(testStock, priceData2);
        Assert.assertArrayEquals(
            new Object[]{-30, "1999-12-30", "2000-01-01"},
            sc.getBiggestChange()
        );
    }

    public static void testGetAllChanges() {
        System.out.println("Running testGetAllChanges");
        Stock testStock = new Stock("AAPL", "Apple Inc.");

        // Empty collection → empty list
        StockCollection sc = new StockCollection(testStock);
        Assert.assertTrue(sc.getAllChanges().isEmpty());

        // Single record → empty list
        sc.addPriceRecord(new PriceRecord(testStock, 100, "2023-01-01"));
        Assert.assertTrue(sc.getAllChanges().isEmpty());

        // Sorted: 90(06-25) → 110(06-29) → 112(07-01) → 105(07-06)
        // Changes: +20, +2, -7
        Object[][] priceData = {
            {110, "2023-06-29"}, {112, "2023-07-01"},
            {90, "2023-06-25"}, {105, "2023-07-06"}
        };
        sc = makeStockCollection(testStock, priceData);

        List<Object[]> changes = sc.getAllChanges();
        Assert.assertEquals(3, changes.size());
        Assert.assertArrayEquals(new Object[]{20, "2023-06-25", "2023-06-29"}, changes.get(0));
        Assert.assertArrayEquals(new Object[]{2, "2023-06-29", "2023-07-01"}, changes.get(1));
        Assert.assertArrayEquals(new Object[]{-7, "2023-07-01", "2023-07-06"}, changes.get(2));
    }
}
