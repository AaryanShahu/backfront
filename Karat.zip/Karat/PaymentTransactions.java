import java.util.*;
import java.util.stream.Collectors;

/**
 * =====================================================================
 * PAYMENT TRANSACTION MONITORING — Karat Coding Problem
 * =====================================================================
 *
 * We are developing a payment transaction monitoring system that tracks
 * accounts and their transactions. The system can compute each account's
 * current balance and basic statistics.
 *
 * Classes:
 *   TransactionType — enum: CREDIT, DEBIT
 *   Transaction     — a single transaction (id, accountId, type, amount, timestampSec)
 *   Account         — an account (accountId, ownerName)
 *   AccountManager  — manages accounts and transactions
 *
 * TASK 1: Read the code. The test is not passing due to a bug.
 *         Find and fix the bug in AccountManager.
 *
 * TASK 2: Implement getAverageTransactionAmountByAccount():
 *   - Return Map<String, Double>: accountId → average |amount| of transactions.
 *   - Both CREDIT and DEBIT considered; use absolute values.
 *   - Accounts with no transactions should NOT appear.
 *
 * TASK 3: Implement getTransactionFees():
 *   - First 3 transactions per account are FREE.
 *   - From 4th onward: CREDIT costs $1, DEBIT costs $2.
 *   - Process in chronological order (by timestampSec).
 *   - Return Map<String, Integer>: accountId → total fees (ALL accounts).
 *
 * TASK 4: Implement getSuspiciousAccounts():
 *   - Consider only DEBIT transactions.
 *   - A DEBIT is "large" if amount >= 50.
 *   - An account is suspicious if it has 3+ large DEBITs within
 *     ANY 60-second window (inclusive of endpoints: t and t+60 are same window).
 *   - Process per-account in chronological order.
 *   - Return sorted List<String> of suspicious accountIds.
 */

enum TransactionType {
    CREDIT, DEBIT
}

class Transaction {
    private String id;
    private String accountId;
    private TransactionType type;
    private int amount;
    private int timestampSec;

    public Transaction(String id, String accountId, TransactionType type,
                       int amount, int timestampSec) {
        this.id = id;
        this.accountId = accountId;
        this.type = type;
        this.amount = amount;
        this.timestampSec = timestampSec;
    }

    public String getId() { return id; }
    public String getAccountId() { return accountId; }
    public TransactionType getType() { return type; }
    public int getAmount() { return amount; }
    public int getTimestampSec() { return timestampSec; }
}

class Account {
    public String accountId;
    public String ownerName;

    public Account(String accountId, String ownerName) {
        this.accountId = accountId;
        this.ownerName = ownerName;
    }

    @Override
    public String toString() {
        return "Account[" + accountId + ", " + ownerName + "]";
    }
}

class AccountManager {
    public List<Account> accounts;
    public List<Transaction> transactions;

    public AccountManager() {
        accounts = new ArrayList<>();
        transactions = new ArrayList<>();
    }

    public void addAccount(Account account) {
        accounts.add(account);
    }

    public void addTransaction(Transaction txn) {
        transactions.add(txn);
    }

    /**
     * TASK 1: This method has a bug. Find and fix it.
     * Returns Map<String, Integer>: accountId → current balance.
     * CREDIT adds to balance, DEBIT subtracts.
     * All accounts should appear (even with 0 balance).
     */
    public Map<String, Integer> getBalances() {
        Map<String, Integer> balances = new HashMap<>();
        for (Account a : accounts) {
            balances.put(a.accountId, 0);
        }
        for (Transaction t : transactions) {
            int current = balances.getOrDefault(t.getAccountId(), 0);
            balances.put(t.getAccountId(),t.getType()==TransactionType.CREDIT? current + t.getAmount():current-t.getAmount());
        }
        return balances;
    }

    /**
     * TASK 2: Average transaction amount per account.
     * Use absolute values. Exclude accounts with no transactions.
     * Return Map<String, Double>: accountId → average |amount|.
     */
    public Map<String, Double> getAverageTransactionAmountByAccount() {
        return transactions.stream().collect(Collectors.groupingBy(e-> e.getAccountId(),Collectors.averagingDouble(e-> e.getAmount())));
    }

    /**
     * TASK 3: Transaction fees per account.
     * First 3 transactions per account are FREE.
     * From 4th: CREDIT=$1, DEBIT=$2.
     * Process in chronological order (timestampSec).
     * Return Map<String, Integer>: accountId → total fees (ALL accounts).
     */
    public Map<String, Integer> getTransactionFees() {
        Map<String,Integer> map1 = new HashMap<>();
        Map<String,List<Transaction>> res=transactions.stream().collect(Collectors.groupingBy(e-> e.getAccountId()));
        for(Map.Entry<String,List<Transaction>> entry1: res.entrySet()){
            int ans = 0;
           List<Transaction> l1 = entry1.getValue().stream().sorted(Comparator.comparing(e-> e.getTimestampSec())).skip(3L).toList();
           for(Transaction t1: l1){
            if(t1.getType().equals(TransactionType.CREDIT)){
                ans += 1;
            }
            else{
                ans +=2 ;
            }
           }
           map1.put(entry1.getKey(), ans);
        }
        return map1;
    }

    /**
     * TASK 4: Suspicious accounts.
     * DEBIT with amount >= 50 is "large".
     * Account is suspicious if 3+ large DEBITs within any 60-sec window.
     * Return sorted List<String> of suspicious accountIds.
     */
    public List<String> getSuspiciousAccounts() {
        List<String> list1 = new ArrayList<>();
        Map<String,List<Transaction>> res=transactions.stream().collect(Collectors.groupingBy(e-> e.getAccountId()));
        for(Map.Entry<String,List<Transaction>> entry1:res.entrySet()){
            List<Transaction> l1 = entry1.getValue().stream().filter(t-> t.getType().equals(TransactionType.DEBIT) && t.getAmount()>=50).sorted(Comparator.comparing(e -> e.getTimestampSec())).toList();
            for(int i=2;i<l1.size();i++){
                if(l1.get(i).getTimestampSec()-l1.get(i-2).getTimestampSec()<=60){
                    list1.add(entry1.getKey());
                    break;
                }
            }
    }
    list1.sort(Comparator.comparing(e-> e+""));
    return list1;
}
}
public class PaymentTransactions {

    private static int passed = 0, failed = 0;

    public static void main(String[] args) {
        System.out.println("\n=== PAYMENT TRANSACTIONS — KARAT PRACTICE ===\n");

        run("TASK 1 — Balances (FIX BUG)", PaymentTransactions::testBalances);
        run("TASK 2 — Average transaction amounts", PaymentTransactions::testAverageAmounts);
        run("TASK 3 — Transaction fees", PaymentTransactions::testTransactionFees);
        run("TASK 4 — Suspicious accounts", PaymentTransactions::testSuspiciousAccounts);

        System.out.println("\n--------------------------------------------------");
        System.out.println("Results: " + passed + " passed, " + failed +
                           " failed out of " + (passed + failed));
    }

    public static void testBalances() {
        AccountManager mgr = new AccountManager();
        mgr.addAccount(new Account("A1", "Alice"));
        mgr.addAccount(new Account("A2", "Bob"));
        mgr.addAccount(new Account("A3", "Carol"));

        mgr.addTransaction(new Transaction("T1", "A1", TransactionType.CREDIT, 100, 10));
        mgr.addTransaction(new Transaction("T2", "A1", TransactionType.DEBIT, 30, 20));
        mgr.addTransaction(new Transaction("T3", "A2", TransactionType.CREDIT, 200, 15));
        mgr.addTransaction(new Transaction("T4", "A2", TransactionType.DEBIT, 50, 25));
        mgr.addTransaction(new Transaction("T5", "A1", TransactionType.CREDIT, 50, 30));

        Map<String, Integer> bal = mgr.getBalances();
        assertEquals(120, bal.get("A1"));
        assertEquals(150, bal.get("A2"));
        assertEquals(0, bal.get("A3"));
    }

    public static void testAverageAmounts() {
        AccountManager mgr = new AccountManager();
        mgr.addAccount(new Account("A1", "Alice"));
        mgr.addAccount(new Account("A2", "Bob"));
        mgr.addAccount(new Account("A3", "Carol"));

        mgr.addTransaction(new Transaction("T1", "A1", TransactionType.CREDIT, 100, 10));
        mgr.addTransaction(new Transaction("T2", "A1", TransactionType.DEBIT, 50, 20));
        mgr.addTransaction(new Transaction("T3", "A1", TransactionType.CREDIT, 30, 30));
        mgr.addTransaction(new Transaction("T4", "A2", TransactionType.DEBIT, 80, 15));
        mgr.addTransaction(new Transaction("T5", "A2", TransactionType.CREDIT, 20, 25));

        Map<String, Double> avg = mgr.getAverageTransactionAmountByAccount();
        assertTrue(Math.abs(avg.get("A1") - 60.0) < 0.1);
        assertTrue(Math.abs(avg.get("A2") - 50.0) < 0.1);
        assertTrue(!avg.containsKey("A3"));
    }

    public static void testTransactionFees() {
        AccountManager mgr = new AccountManager();
        mgr.addAccount(new Account("A1", "Alice"));
        mgr.addAccount(new Account("A2", "Bob"));

        mgr.addTransaction(new Transaction("T1", "A1", TransactionType.CREDIT, 100, 10));
        mgr.addTransaction(new Transaction("T2", "A1", TransactionType.DEBIT, 50, 20));
        mgr.addTransaction(new Transaction("T3", "A1", TransactionType.CREDIT, 30, 30));
        mgr.addTransaction(new Transaction("T4", "A1", TransactionType.CREDIT, 40, 40));
        mgr.addTransaction(new Transaction("T5", "A1", TransactionType.DEBIT, 20, 50));

        mgr.addTransaction(new Transaction("T6", "A2", TransactionType.DEBIT, 80, 15));
        mgr.addTransaction(new Transaction("T7", "A2", TransactionType.CREDIT, 20, 25));
        mgr.addTransaction(new Transaction("T8", "A2", TransactionType.DEBIT, 10, 35));
        mgr.addTransaction(new Transaction("T9", "A2", TransactionType.DEBIT, 60, 45));

        Map<String, Integer> fees = mgr.getTransactionFees();
        assertEquals(3, fees.get("A1"));
        assertEquals(2, fees.get("A2"));
    }

    public static void testSuspiciousAccounts() {
        AccountManager mgr = new AccountManager();
        mgr.addAccount(new Account("A1", "Alice"));
        mgr.addAccount(new Account("A2", "Bob"));
        mgr.addAccount(new Account("A3", "Carol"));

        mgr.addTransaction(new Transaction("T1", "A1", TransactionType.DEBIT, 60, 100));
        mgr.addTransaction(new Transaction("T2", "A1", TransactionType.DEBIT, 70, 130));
        mgr.addTransaction(new Transaction("T3", "A1", TransactionType.DEBIT, 55, 160));

        mgr.addTransaction(new Transaction("T4", "A2", TransactionType.DEBIT, 80, 100));
        mgr.addTransaction(new Transaction("T5", "A2", TransactionType.DEBIT, 90, 200));
        mgr.addTransaction(new Transaction("T6", "A2", TransactionType.DEBIT, 50, 300));

        mgr.addTransaction(new Transaction("T7", "A3", TransactionType.DEBIT, 60, 100));
        mgr.addTransaction(new Transaction("T8", "A3", TransactionType.DEBIT, 30, 120));
        mgr.addTransaction(new Transaction("T9", "A3", TransactionType.DEBIT, 55, 140));

        mgr.addTransaction(new Transaction("T10", "A1", TransactionType.CREDIT, 200, 105));

        List<String> suspicious = mgr.getSuspiciousAccounts();
        assertListEquals(List.of("A1"), suspicious);
    }

    // ================================================================
    //                      HELPERS
    // ================================================================

    private static void run(String name, Runnable test) {
        try {
            test.run();
            passed++;
            System.out.println("  PASS: " + name);
        } catch (Exception | AssertionError e) {
            failed++;
            System.out.println("  FAIL: " + name + " -> " + e.getMessage());
        }
    }

    private static void assertEquals(Object expected, Object actual) {
        if (!Objects.equals(expected, actual))
            throw new AssertionError("Expected [" + expected + "] but got [" + actual + "]");
    }

    private static void assertListEquals(List<?> expected, List<?> actual) {
        if (!Objects.equals(expected, actual))
            throw new AssertionError("Expected " + expected + " but got " + actual);
    }

    private static void assertTrue(boolean condition) {
        if (!condition) throw new AssertionError("Condition was false");
    }

}
